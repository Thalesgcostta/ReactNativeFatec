import HelloWorld from './components/hello-world/HelloWorld'
import HelloWorld2 from './components/hello-world/HelloWorld2'
import Light from './components/light/Light'
export default function App(){

  return <Light/>
}
