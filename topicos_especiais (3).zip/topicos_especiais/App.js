import HelloWorld from './components/hello-world/HelloWorld'
import HelloWorld2 from './components/hello-world/HelloWorld2'
import Light from './components/light/Light'
import Login from './components/login-page/Login'
export default function App(){

  return <Login/>
}
