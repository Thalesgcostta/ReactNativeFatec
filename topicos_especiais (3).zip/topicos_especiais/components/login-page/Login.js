import {SafeAreaView, View, Text, StyleSheet, StatusBar, TextInput, TouchableOpacity} from "react-native"
import Constants from "expo-constants"
import {FontAwesome5} from "@expo/vector-icons"
export default function Login(){
  return(
  <SafeAreaView style={styles.container}>
    <StatusBar backgroundColor= "#fff"/>
    <View style={styles.content}>
      <View style={styles.textWrapper}>
        <Text style={styles.userText}> Ola </Text>
        <Text style={styles.userText}> Fulano de tal </Text>
        <Text style={styles.userText}> Seja Bem-Vindo </Text>
      </View>
      <View style={styles.form}>
      <FontAwesome5 style={styles.iconLock} name="lock"/>
      <TextInput style={styles.password}/>
      <TouchableOpacity>
        <Text> Entrar a senha </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Text> Entrar assim mesmo </Text>
      </TouchableOpacity>
      </View>
    </View>
  </SafeAreaView>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#45ccea",
    paddingTop: Constants.statusBarHeight
  },
  content:{
    paddingHorizontal: 30
  },
  textWrapper:{
    marginTop: 60,
    marginBottom: 30
  },
  userText:{
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    lineHeight: 30
  },
  form:{
    marginBottom: 30
  },
  iconLock:{
    color: "#929292",
    position: "absolute",
    fontSize: 15,
    top: 22,
    left: 22,
    zIndex: 10
  },
  password:{
    height: 60,
    borderRadius: 30,
    paddingHorizontal: 30,
    fontSize: 20,
    color: "#929292",
    backgroundColor: "#fff",
    textAlign: "center",
    textAlignVertical: "center"

  }
})