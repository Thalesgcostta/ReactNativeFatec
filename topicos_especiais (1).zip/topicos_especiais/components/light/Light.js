import {SafeAreaView, Text} from 'react-native';
export default function Light(){
  return(
    <SafeAreaView>
    <Text> App da Lâmpada mágica </Text>
    </SafeAreaView>
  );
}